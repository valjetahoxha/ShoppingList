package hu.ait.shoppinglist.ui


import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import kotlin.text.Typography.dagger


@HiltAndroidApp
class MyApp : Application() {
}
